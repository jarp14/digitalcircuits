## After the automatic generation of the graphical editor using Eugenia, replace the following icons:

org.chico.digitalcircuits.diagram/icons/obj16/DigitalDiagramFile.gif
org.chico.digitalcircuits.diagram/icons/wizban/NewDigitalWizard.gif
org.chico.digitalcircuits.edit/icons/full/obj16/*.gif
org.chico.digitalcircuits.editor/icons/full/obj16/DigitalModelFile.gif
org.chico.digitalcirtuits.editor/icons/full/wizban/NewDigital.gif

* = logical gates and links 